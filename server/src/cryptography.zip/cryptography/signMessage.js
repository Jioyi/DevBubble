const crypto = require('crypto');
const hash = crypto.createHash('sha256');
const fs = require('fs');
const encrypt = require('./encrypt');
const decrypt = require('./decrypt');

const data = {
    alguna: 'data',
    importante: 'para',
    guardar: '.'
}

const stringifyData = JSON.stringify(data);

hash.update(stringifyData);

const hashedData = hash.digest('hex');

const senderPrivateKey = fs.readFileSync(__dirname + '/id_rsa_pri.pem', 'utf8');

const signedMessage = encrypt.withPrivateKey(senderPrivateKey, hashedData);

const packageOfDataToSend = {
    algorithm: 'sha256',
    originalData: data,
    signedEncryptedData: signedMessage
}

module.exports.packageOfDataToSend = packageOfDataToSend;
