const crypto = require('crypto');
const fs = require('fs');
const decrypt = require('./decrypt');

const receivedData = require('./signMessage').packageOfDataToSend;

const hash = crypto.createHash(receivedData.algorithm);

const publicKey = fs.readFileSync(__dirname + '/id_rsa_pub.pem', 'utf8');

const message =  decrypt.withPublicKey(publicKey, receivedData.signedEncryptedData)
const messageHex = message.toString();

const hashOriginal = hash.update(JSON.stringify(receivedData.originalData));
const hashOriginalHex = hash.digest('hex');

console.log(hashOriginalHex === messageHex)
